"""
@Author: Yu Huang
@Email: yuhuang-cst@foxmail.com
"""

class BaseDataHelper(object):
	def __init__(self):
		pass



